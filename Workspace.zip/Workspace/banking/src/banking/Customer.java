package banking;

   class Customer {
   String firstName;
   String lastName;
  
  public String getfirstName() {
	  return firstName;
  }
  public void setfirstName(String firstName) {
	  this.firstName = firstName;
  }
  public String getlastName() {
	  return lastName;
  }
  public void setlastName(String lastName) {
	  this.lastName = lastName;
  }
}
